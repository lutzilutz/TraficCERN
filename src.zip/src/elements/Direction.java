package elements;

public enum Direction {
	left,
	right,
	straight;
}
