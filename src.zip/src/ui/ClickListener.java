package ui;

public interface ClickListener {

	public void onClick();
	
}
